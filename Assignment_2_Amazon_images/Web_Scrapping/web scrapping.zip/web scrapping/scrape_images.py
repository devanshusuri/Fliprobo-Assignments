def  scrap_images_url(driver):
     #price=driver.find_elements_by_xpath("//img[@class='sb_1kFdf5oU']")
     tshirt=driver.find_elements_by_xpath("//div[@class='a-section aok-relative s-image-tall-aspect']//img")
     print(len(tshirt))
     product_data={}

     product_data['image_urls']=[]
        
     for image in tshirt:
         source=image.get_attribute('src')
         product_data["image_urls"].append(source)
     print("R S Data")

     return product_data
     

